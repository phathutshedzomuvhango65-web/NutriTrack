NUTRITRACK 2.0 UPDATE
1. Open your existing GitHub repository in Chrome.
2. Choose Add file > Upload files.
3. Upload index.html to the repository root and replace the existing index.html.
4. Commit changes to main.
5. Wait for GitHub Pages deployment, then refresh your public site.

This is a browser-only demo. Food diary, plans, habits and shopping list are saved
in local browser storage. It does not yet provide secure accounts or cloud sync.
A backend such as Supabase must be configured with authentication and secure
database access policies before collecting user information. Never publish a
service-role secret key in a public repository.
